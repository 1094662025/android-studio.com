# 📱 User Management Mobile App

Aplicación móvil desarrollada con Kotlin para Android que consume una
API REST desarrollada con ASP.NET Core y utiliza MySQL como sistema
de persistencia.

## 🚀 Tecnologías

### Mobile
- Kotlin
- Android Studio
- Retrofit
- Gson
- XML Layouts

### Backend
- C#
- ASP.NET Core Web API
- Entity Framework Core
- BCrypt
- Repository Pattern

### Database
- MySQL

## 🏗️ Arquitectura

Android App
    ↓
Retrofit
    ↓
ASP.NET Core REST API
    ↓
Controller
    ↓
Service
    ↓
Repository
    ↓
Entity Framework Core
    ↓
MySQL

## 🔐 Autenticación

Las contraseñas no se almacenan en texto plano.

Durante el registro:

Password → BCrypt Hash → MySQL

Durante el login:

Password → BCrypt Verify → PasswordHash

## 📌 Funcionalidades

- Registro de usuarios
- Inicio de sesión
- Validación de credenciales
- Hash seguro de contraseñas
- Consulta de usuarios
- Actualización de usuarios
- Eliminación de usuarios
- Fecha de nacimiento, universidad y semestre del estudiante (la edad se calcula en el servidor)
- Consumo de API REST desde Android

## 🔗 Endpoints

| Método | Endpoint | Descripción |
|---|---|---|
| GET | /api/Usuarios | Consultar usuarios |
| GET | /api/Usuarios/{id} | Consultar usuario |
| POST | /api/Usuarios | Crear usuario (nombre, apellido, correo, password, fechaNacimiento, universidad, semestre) |
| POST | /api/Usuarios/login | Iniciar sesión |
| PUT | /api/Usuarios/{id} | Actualizar usuario |
| DELETE | /api/Usuarios/{id} | Eliminar usuario |

## 🗄️ Base de datos

Los scripts para la nueva estructura de la tabla `Usuarios` están en la carpeta `Database/`:

- `01_actualizar_tabla_usuarios.sql`: modifica una tabla existente (quita `Edad` y `RolId`; agrega `FechaNacimiento`, `Universidad` y `Semestre`).
- `00_crear_tabla_usuarios_nueva.sql`: crea la tabla desde cero (opcional).

## 📨 Ejemplo de registro (POST /api/Usuarios)

```json
{
  "nombre": "Alexander",
  "apellido": "Pérez",
  "correo": "alexander@correo.com",
  "password": "123456",
  "fechaNacimiento": "2003-08-25",
  "universidad": "UCompensar",
  "semestre": 5
}
```

Errores controlados (HTTP 400): `{ "mensaje": "Ya existe un usuario con ese correo." }`
