-- =====================================================================
-- ACTIVIDAD UCompensar - Cambios en la tabla Usuarios (MySQL 8)
-- Ejecutar sobre la base de datos configurada en appsettings.json
--   - Elimina:  Edad, RolId
--   - Agrega:   FechaNacimiento, Universidad, Semestre
-- Los usuarios existentes conservan datos aproximados:
--   FechaNacimiento se estima restando su Edad a la fecha actual.
-- =====================================================================

-- 1) Agregar columnas nuevas (con valor por defecto temporal)
ALTER TABLE Usuarios
    ADD COLUMN FechaNacimiento DATE         NOT NULL DEFAULT '2000-01-01',
    ADD COLUMN Universidad     VARCHAR(150) NOT NULL DEFAULT '',
    ADD COLUMN Semestre        INT          NOT NULL DEFAULT 1;

-- 2) Migrar datos existentes: estimar fecha de nacimiento desde Edad
UPDATE Usuarios
   SET FechaNacimiento = DATE_SUB(CURDATE(), INTERVAL Edad YEAR)
 WHERE Edad IS NOT NULL AND Edad > 0;

-- 3) Quitar los valores por defecto temporales
ALTER TABLE Usuarios
    ALTER COLUMN FechaNacimiento DROP DEFAULT,
    ALTER COLUMN Universidad     DROP DEFAULT,
    ALTER COLUMN Semestre        DROP DEFAULT;

-- 4) Eliminar columnas que ya no se usan
ALTER TABLE Usuarios
    DROP COLUMN Edad,
    DROP COLUMN RolId;

-- 5) Verificar el resultado
DESCRIBE Usuarios;
SELECT Id, Nombre, Apellido, Correo, FechaNacimiento, Universidad, Semestre
  FROM Usuarios;
