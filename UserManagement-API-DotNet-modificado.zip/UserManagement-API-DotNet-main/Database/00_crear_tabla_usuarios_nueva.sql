-- =====================================================================
-- OPCIONAL: crear la tabla Usuarios desde cero con la nueva estructura
-- (solo si NO existe todavía la tabla o desea reiniciarla).
-- =====================================================================
CREATE TABLE IF NOT EXISTS Usuarios (
    Id              INT           NOT NULL AUTO_INCREMENT,
    Nombre          VARCHAR(100)  NOT NULL,
    Apellido        VARCHAR(100)  NOT NULL,
    Correo          VARCHAR(150)  NOT NULL,
    PasswordHash    LONGTEXT      NOT NULL,
    FechaNacimiento DATE          NOT NULL,
    Universidad     VARCHAR(150)  NOT NULL,
    Semestre        INT           NOT NULL,
    Activo          TINYINT(1)    NOT NULL DEFAULT 1,
    FechaCreacion   DATETIME(6)   NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_Usuarios_Correo (Correo)
);
