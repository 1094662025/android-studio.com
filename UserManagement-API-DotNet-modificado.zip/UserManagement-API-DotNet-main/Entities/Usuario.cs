namespace UsuariosApi.Entities;

public class Usuario
{
    public int Id { get; set; }

    public string Nombre { get; set; } = string.Empty;

    public string Apellido { get; set; } = string.Empty;

    public string Correo { get; set; } = string.Empty;

    // La contraseña NO se guarda en texto plano
    public string PasswordHash { get; set; } = string.Empty;

    // La edad ya NO se almacena: se calcula a partir de la fecha de nacimiento
    public DateTime FechaNacimiento { get; set; }

    public string Universidad { get; set; } = string.Empty;

    // Semestre actual del estudiante (1 a 10)
    public int Semestre { get; set; }

    public bool Activo { get; set; } = true;

    public DateTime FechaCreacion { get; set; } = DateTime.Now;
}
