namespace UsuariosApi.Helpers;

public static class EdadHelper
{
    public const int EdadMaxima = 120;

    // Calcula la edad considerando año, mes y día
    // (no basta con restar los años).
    public static int Calcular(DateTime fechaNacimiento, DateTime? referencia = null)
    {
        var hoy = (referencia ?? DateTime.Today).Date;
        var nacimiento = fechaNacimiento.Date;

        var edad = hoy.Year - nacimiento.Year;

        // Si todavía no ha cumplido años este año, se resta uno
        if (nacimiento > hoy.AddYears(-edad))
        {
            edad--;
        }

        return edad;
    }

    // Devuelve un mensaje de error o null si la fecha es válida
    public static string? ValidarFechaNacimiento(DateTime fechaNacimiento)
    {
        if (fechaNacimiento.Date > DateTime.Today)
        {
            return "La fecha de nacimiento no puede ser futura.";
        }

        if (Calcular(fechaNacimiento) > EdadMaxima)
        {
            return "La fecha de nacimiento no es válida.";
        }

        return null;
    }
}
