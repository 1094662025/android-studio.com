package com.example.parcialkotlinapp.models

// Datos que se envían al API para crear un usuario.
// Ya no se envía Edad ni RolId: la edad la calcula el servidor
// a partir de la fecha de nacimiento (formato "yyyy-MM-dd").
data class CrearUsuarioRequest(
    val nombre: String,
    val apellido: String,
    val correo: String,
    val password: String,
    val fechaNacimiento: String,
    val universidad: String,
    val semestre: Int
)
