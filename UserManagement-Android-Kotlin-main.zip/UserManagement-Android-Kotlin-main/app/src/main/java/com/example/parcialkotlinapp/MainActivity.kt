package com.example.parcialkotlinapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.parcialkotlinapp.utils.SaludoUtils
import com.example.parcialkotlinapp.utils.aplicarInsetsDelSistema
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // =====================================
        // USUARIO AUTENTICADO (viene del Login)
        // =====================================
        // Si por algún motivo no hay usuario, no se muestra la
        // pantalla principal y se vuelve al Login.
        val nombreUsuario = intent.getStringExtra("nombreUsuario")

        if (nombreUsuario.isNullOrBlank()) {
            irAlLogin()
            return
        }

        enableEdgeToEdge()

        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.main)
            .aplicarInsetsDelSistema()

        // =====================================
        // SALUDO SEGÚN LA HORA DEL DISPOSITIVO
        // =====================================
        val tvSaludo = findViewById<TextView>(R.id.tvSaludo)

        tvSaludo.text =
            "${SaludoUtils.saludoActual()}, $nombreUsuario"

        // =====================================
        // ÍCONO CERRAR SESIÓN (esquina superior)
        // =====================================
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)

        toolbar.setOnMenuItemClickListener { item ->

            if (item.itemId == R.id.action_cerrar_sesion) {
                mostrarDialogoCerrarSesion()
                true
            } else {
                false
            }
        }

        // =====================================
        // BOTÓN EJERCICIO PAR O IMPAR
        // =====================================
        val btnParImpar =
            findViewById<Button>(R.id.btnParImpar)

        btnParImpar.setOnClickListener {

            val intent = Intent(
                this,
                ParImparActivity::class.java
            )

            startActivity(intent)
        }
    }

    // =====================================
    // CONFIRMACIÓN DE CIERRE DE SESIÓN
    // =====================================
    private fun mostrarDialogoCerrarSesion() {

        MaterialAlertDialogBuilder(this)
            .setTitle("Cerrar sesión")
            .setMessage("¿Está seguro de que desea cerrar sesión?")
            .setNegativeButton("CANCELAR") { dialogo, _ ->
                // Solo cierra el cuadro; el usuario sigue en la pantalla principal
                dialogo.dismiss()
            }
            .setPositiveButton("SALIR") { _, _ ->
                irAlLogin()
            }
            .show()
    }

    // =====================================
    // VOLVER AL LOGIN BORRANDO LA PILA
    // =====================================
    // NEW_TASK + CLEAR_TASK elimina todas las pantallas de la sesión
    // anterior, así el botón Atrás no puede regresar a ellas.
    private fun irAlLogin() {

        val intent = Intent(this, LoginActivity::class.java)

        intent.flags =
            Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(intent)

        finish()
    }
}
