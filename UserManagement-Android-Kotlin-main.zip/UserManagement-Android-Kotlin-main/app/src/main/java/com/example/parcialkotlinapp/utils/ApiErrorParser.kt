package com.example.parcialkotlinapp.utils

import com.google.gson.JsonParser
import retrofit2.Response

// Interpreta los errores HTTP que devuelve el API .NET.
//
// El backend responde errores controlados así:
//   HTTP 400  { "mensaje": "Ya existe un usuario con ese correo." }
// Esta clase lee ese "mensaje" para mostrarlo al usuario, en lugar
// de mostrar un error genérico como "Error 500".
object ApiErrorParser {

    fun obtenerMensaje(response: Response<*>): String {

        val codigo = response.code()

        val cuerpo = try {
            response.errorBody()?.string()
        } catch (e: Exception) {
            null
        }

        // 1) Mensaje enviado por el backend
        val mensajeApi = extraerMensaje(cuerpo)

        if (!mensajeApi.isNullOrBlank()) {
            return mensajeApi
        }

        // 2) Si el backend no envió mensaje, uno según el código
        return when (codigo) {
            400 -> "Los datos enviados no son válidos."
            401 -> "Correo o contraseña incorrectos."
            404 -> "No se encontró el recurso solicitado."
            in 500..599 -> "Error interno del servidor ($codigo). Intente más tarde."
            else -> "Error inesperado ($codigo)."
        }
    }

    private fun extraerMensaje(json: String?): String? {

        if (json.isNullOrBlank()) return null

        return try {

            val elemento = JsonParser.parseString(json)

            if (!elemento.isJsonObject) return null

            val objeto = elemento.asJsonObject

            // Formato propio del API: { "mensaje": "..." }
            val mensaje = objeto.get("mensaje")

            if (mensaje != null && mensaje.isJsonPrimitive) {
                return mensaje.asString
            }

            // Formato estándar de ASP.NET (ProblemDetails): "title" / "detail"
            val detalle = objeto.get("detail")

            if (detalle != null && detalle.isJsonPrimitive) {
                return detalle.asString
            }

            null

        } catch (e: Exception) {
            // El cuerpo no era JSON (por ejemplo una página HTML de error)
            null
        }
    }
}
