package com.example.parcialkotlinapp

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.parcialkotlinapp.api.ApiClient
import com.example.parcialkotlinapp.models.CrearUsuarioRequest
import com.example.parcialkotlinapp.models.Usuario
import com.example.parcialkotlinapp.utils.ApiErrorParser
import com.example.parcialkotlinapp.utils.EdadUtils
import com.example.parcialkotlinapp.utils.aplicarInsetsDelSistema
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar

class RegistroActivity : AppCompatActivity() {

    // Fecha de nacimiento elegida en el DatePicker
    private var anioNacimiento: Int? = null
    private var mesNacimiento: Int? = null   // 1 a 12
    private var diaNacimiento: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContentView(R.layout.activity_registro)

        findViewById<View>(R.id.root).aplicarInsetsDelSistema()

        // =====================================
        // FLECHA SUPERIOR: REGRESAR A LA PANTALLA ANTERIOR
        // =====================================
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)

        toolbar.setNavigationOnClickListener {
            finish()
        }

        // =====================================
        // COMPONENTES
        // =====================================
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etApellido = findViewById<EditText>(R.id.etApellido)
        val etCorreo = findViewById<EditText>(R.id.etCorreoRegistro)
        val etPasswordRegistro = findViewById<EditText>(R.id.etPasswordRegistro)
        val etFechaNacimiento = findViewById<EditText>(R.id.etFechaNacimiento)
        val tvEdadCalculada = findViewById<TextView>(R.id.tvEdadCalculada)
        val etUniversidad = findViewById<EditText>(R.id.etUniversidad)
        val spSemestre = findViewById<Spinner>(R.id.spSemestre)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)
        val tvMensaje = findViewById<TextView>(R.id.tvMensajeRegistro)

        // =====================================
        // SEMESTRE (1 a 10)
        // =====================================
        val semestres = mutableListOf("Seleccione un semestre")

        for (i in 1..10) {
            semestres.add(i.toString())
        }

        val adaptador = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            semestres
        )

        adaptador.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        spSemestre.adapter = adaptador

        // =====================================
        // FECHA DE NACIMIENTO (DatePicker)
        // =====================================
        etFechaNacimiento.setOnClickListener {

            val hoy = Calendar.getInstance()

            // Fecha inicial del selector: la ya elegida o hace 18 años
            val anioInicial =
                anioNacimiento ?: (hoy.get(Calendar.YEAR) - 18)

            val mesInicial =
                (mesNacimiento ?: (hoy.get(Calendar.MONTH) + 1)) - 1

            val diaInicial =
                diaNacimiento ?: hoy.get(Calendar.DAY_OF_MONTH)

            val selector = DatePickerDialog(
                this,
                { _, anio, mes, dia ->

                    // El DatePicker entrega el mes de 0 a 11
                    anioNacimiento = anio
                    mesNacimiento = mes + 1
                    diaNacimiento = dia

                    etFechaNacimiento.setText(
                        EdadUtils.formatoVisible(anio, mes + 1, dia)
                    )
                    etFechaNacimiento.error = null

                    // La edad se calcula con día, mes y año
                    val edad = EdadUtils.calcular(anio, mes + 1, dia)

                    tvEdadCalculada.text = "Edad: $edad años"
                    tvEdadCalculada.visibility = View.VISIBLE
                },
                anioInicial,
                mesInicial,
                diaInicial
            )

            // No se permiten fechas futuras
            selector.datePicker.maxDate = System.currentTimeMillis()

            selector.show()
        }

        // =====================================
        // BOTÓN REGISTRAR
        // =====================================
        btnRegistrar.setOnClickListener {

            val nombre = etNombre.text.toString().trim()
            val apellido = etApellido.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val password = etPasswordRegistro.text.toString()
            val universidad = etUniversidad.text.toString().trim()
            val semestre = spSemestre.selectedItemPosition   // 0 = sin elegir

            // ---------- VALIDACIONES ----------
            if (nombre.isBlank()) {
                etNombre.error = "Ingrese el nombre"
                return@setOnClickListener
            }

            if (apellido.isBlank()) {
                etApellido.error = "Ingrese el apellido"
                return@setOnClickListener
            }

            if (correo.isBlank()) {
                etCorreo.error = "Ingrese el correo"
                return@setOnClickListener
            }

            if (!android.util.Patterns.EMAIL_ADDRESS
                    .matcher(correo)
                    .matches()
            ) {
                etCorreo.error = "Correo no válido"
                return@setOnClickListener
            }

            if (password.isBlank()) {
                etPasswordRegistro.error = "Ingrese la contraseña"
                return@setOnClickListener
            }

            if (password.length < 6) {
                etPasswordRegistro.error =
                    "La contraseña debe tener mínimo 6 caracteres"
                return@setOnClickListener
            }

            val anio = anioNacimiento
            val mes = mesNacimiento
            val dia = diaNacimiento

            if (anio == null || mes == null || dia == null) {
                etFechaNacimiento.error = "Seleccione la fecha de nacimiento"
                return@setOnClickListener
            }

            if (universidad.isBlank()) {
                etUniversidad.error = "Ingrese la universidad"
                return@setOnClickListener
            }

            if (semestre < 1 || semestre > 10) {
                mostrarError(
                    tvMensaje,
                    "Seleccione un semestre entre 1 y 10"
                )
                return@setOnClickListener
            }

            // ---------- OBJETO QUE SE ENVÍA AL BACKEND ----------
            val nuevoUsuario = CrearUsuarioRequest(
                nombre = nombre,
                apellido = apellido,
                correo = correo,
                password = password,
                fechaNacimiento = EdadUtils.formatoApi(anio, mes, dia),
                universidad = universidad,
                semestre = semestre
            )

            tvMensaje.setTextColor(Color.DKGRAY)
            tvMensaje.text = "Registrando usuario..."

            // Evitar varios clics mientras responde la API
            btnRegistrar.isEnabled = false

            // ---------- LLAMADA AL BACKEND ----------
            ApiClient.usuarioApi
                .crearUsuario(nuevoUsuario)
                .enqueue(object : Callback<Usuario> {

                    override fun onResponse(
                        call: Call<Usuario>,
                        response: Response<Usuario>
                    ) {

                        btnRegistrar.isEnabled = true

                        // REGISTRO EXITOSO
                        if (response.isSuccessful) {

                            tvMensaje.text = ""

                            mostrarDialogoRegistroExitoso()

                        }
                        // ERROR DEL BACKEND (400 correo duplicado, etc.)
                        else {

                            val mensaje =
                                ApiErrorParser.obtenerMensaje(response)

                            mostrarError(tvMensaje, mensaje)

                            // Si el problema es el correo, se resalta ese campo
                            if (mensaje.contains("correo", ignoreCase = true)) {
                                etCorreo.error = mensaje
                                etCorreo.requestFocus()
                            }
                        }
                    }

                    override fun onFailure(
                        call: Call<Usuario>,
                        t: Throwable
                    ) {

                        btnRegistrar.isEnabled = true

                        mostrarError(
                            tvMensaje,
                            "No se pudo conectar con el servidor: ${t.message}"
                        )
                    }
                })
        }
    }

    // =====================================
    // ALERTDIALOG: REGISTRO EXITOSO
    // =====================================
    private fun mostrarDialogoRegistroExitoso() {

        if (isFinishing || isDestroyed) return

        MaterialAlertDialogBuilder(this)
            .setTitle("Registro exitoso")
            .setMessage("El usuario fue creado exitosamente.")
            .setCancelable(false)
            .setPositiveButton("ACEPTAR") { _, _ ->

                // Regresar al Login para iniciar sesión
                val intent = Intent(this, LoginActivity::class.java)

                intent.flags =
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP

                startActivity(intent)

                finish()
            }
            .show()
    }

    private fun mostrarError(tv: TextView, mensaje: String) {
        tv.setTextColor(Color.parseColor("#C62828"))
        tv.text = mensaje
    }
}
