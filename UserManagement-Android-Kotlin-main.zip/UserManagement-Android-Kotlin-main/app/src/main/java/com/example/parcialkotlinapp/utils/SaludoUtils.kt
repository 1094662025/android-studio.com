package com.example.parcialkotlinapp.utils

import java.util.Calendar

object SaludoUtils {

    // 05:00 - 11:59 -> Buenos días
    // 12:00 - 17:59 -> Buenas tardes
    // 18:00 - 04:59 -> Buenas noches
    fun saludoPorHora(hora: Int): String = when (hora) {
        in 5..11 -> "Buenos días"
        in 12..17 -> "Buenas tardes"
        else -> "Buenas noches"
    }

    // Usa la hora actual del dispositivo
    fun saludoActual(): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return saludoPorHora(hora)
    }
}
