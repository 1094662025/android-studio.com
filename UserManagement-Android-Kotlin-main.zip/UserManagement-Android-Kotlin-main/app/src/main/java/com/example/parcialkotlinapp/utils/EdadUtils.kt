package com.example.parcialkotlinapp.utils

import java.util.Calendar
import java.util.Locale

object EdadUtils {

    // Calcula la edad considerando día, mes y año
    // (no solo la resta de años).
    // mes: 1 a 12
    fun calcular(
        anioNacimiento: Int,
        mesNacimiento: Int,
        diaNacimiento: Int,
        hoy: Calendar = Calendar.getInstance()
    ): Int {

        var edad = hoy.get(Calendar.YEAR) - anioNacimiento

        val mesActual = hoy.get(Calendar.MONTH) + 1
        val diaActual = hoy.get(Calendar.DAY_OF_MONTH)

        // Si aún no ha cumplido años este año, se resta uno
        if (mesActual < mesNacimiento ||
            (mesActual == mesNacimiento && diaActual < diaNacimiento)
        ) {
            edad--
        }

        return edad
    }

    // Formato que espera el API: 2003-08-25
    fun formatoApi(anio: Int, mes: Int, dia: Int): String =
        String.format(Locale.US, "%04d-%02d-%02d", anio, mes, dia)

    // Formato que ve el usuario: 25/08/2003
    fun formatoVisible(anio: Int, mes: Int, dia: Int): String =
        String.format(Locale.US, "%02d/%02d/%04d", dia, mes, anio)
}
