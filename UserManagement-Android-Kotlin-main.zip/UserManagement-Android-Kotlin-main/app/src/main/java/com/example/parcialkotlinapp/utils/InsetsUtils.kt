package com.example.parcialkotlinapp.utils

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

// Evita que el contenido quede debajo de la barra de estado,
// la barra de navegación o el teclado (pantalla de borde a borde).
// Se suma al padding original que tenga la vista en el XML.
fun View.aplicarInsetsDelSistema() {

    val izquierda = paddingLeft
    val arriba = paddingTop
    val derecha = paddingRight
    val abajo = paddingBottom

    ViewCompat.setOnApplyWindowInsetsListener(this) { vista, insets ->

        val barras = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.ime()
        )

        vista.setPadding(
            izquierda + barras.left,
            arriba + barras.top,
            derecha + barras.right,
            abajo + barras.bottom
        )

        insets
    }
}
